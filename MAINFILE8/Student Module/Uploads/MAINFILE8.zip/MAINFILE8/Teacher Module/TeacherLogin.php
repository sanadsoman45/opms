<?php
    require_once 'conn.php';
    error_reporting(E_ALL & ~E_NOTICE);
    if(isset($_POST["function"])){
        if($_POST['function']=="teacher_login"){
            teacher_login();
        }
    }
    function teacher_login(){
        $conn1=createconn1();
        $id=$_POST["userid"];
        $pass=$_POST["password"];
        if(!$conn1){
            $return_data["connerror"]="yes";
        }else{
            mysqli_select_db($conn1,"projectsubmission");
            $result1=mysqli_query($conn1,"Select * from teacher where t_id=$id");
            $row=mysqli_fetch_array($result1);
            if(mysqli_num_rows($result1)>0){
                if($row["t_pass"]!=""){
                    if($row["t_pass"]==md5($pass)){
                        $return_data["tid"]=$row["t_id"];
                        $return_data["tname"]=$row["t_name"];
                        $return_data["tpin"]=$row["t_pin"];
                        $return_data["temail"]=$row["t_email"];
                        $return_data["tpn"]=$row["t_pn"];
                    }else{
                        $return_data["invalidpass"]="true";
                    }
                }else{
                    $return_data["passnotset"]="true";
                }
            }else{
                $return_data["invalidid"]="invalidid";
            }
        }
        echo json_encode($return_data);
        exit();
    }
?>
<html>
    <head>
        <title>Teacher Login</title>

        <link href="css/TeacherStyle.css" rel="stylesheet" />
        <link href="css/RePass1.css" rel="stylesheet" />
        <link href="css/RSwal.css" rel="stylesheet" />
        <link href="css/WSwal.css" rel="stylesheet" />

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.js"></script>
        <script src="js/mainpageslide.js"></script> 
        <script src="js/EyeIcon.js"></script>
        <script src="js/RightWrongPopup1.js"></script>
        <script src="js/teacher_ajax.js"></script>
        <script>
            $(window).bind("pageshow", function() {
                $('form').get(0).reset();
            });
        </script>
        <script>
            $(document).ready(function(){
                if(localStorage.getItem("tname") !=null)
                {
                    $.post("TeacherModule.php",function(){
                        location.href="TeacherModule.php";
                    });
                }
            }); 
        </script>
    </head>
    <body>
        <!-- /////////////////////////////////////////////////////////////////////////// Starting Logo-->
        <div id="mcc-info">
            <img src="photo/mcclogo.png" alt="MCC LOGO" width="150" height="180"><br>
            <div id="mcctxtcont">
                <div id="mcctag">
                    MULUND COLLEGE OF COMMERCE
                </div>
                <p class="pms1">
                    PROJECT MANAGEMENT SYSTEM
                </p>
            </div>
        </div>

        <!-- /////////////////////////////////////////////////////////////////////////// LOGIN-->
        <div class="mcc-login">
            <img src="photo/mcclogo.png" alt="MCC LOGO" width="100" height="120">
            <p class="pms2">
                PROJECT MANAGEMENT SYSTEM
            </p>
            <br><br><br>
            <div id="flip-card">
                <header class="header1">Login</header>
                <form name="form1" method="POST" id="form-1" onsubmit="return false">
                    <div class="input-field0" id="user-id1">
                        <input type="text" id="user_id1" name="userid1" class="textbox0" required/>
                        <label>UserID</label>
                    </div>
                    
                    <div class="input-field0"  id="pass-word1">
                        <input type="password" id="pass_word1" name="password1" class="textbox0" required/>
                        <label>Password</label>
                        <span id="outer-eye1">
                            <i id="eye1" show="no" class="fas pslash-eye"></i>
                        </span>
                    </div>

                    <div class="btn1" id="btn-1">
                        <div class="inner1"></div>
                        <input type="submit" name="login1" class="login-btn1" value="LOGIN" id="log_in1" onclick="login()"/>
                    </div>

                    <span class="forgot_password1" id= "forgot-password1">Forgot Password?</span>
                </form>
            </div>
        </div>
        <!-- /////////////////////////////////////////////////////////////////////////// -->

        <!-- /////////////////////////////////////////////////////////////////////////// RESET PASSWORD-->
        <div class="outer-block" id="outer_block">
            <div class="inner-block" id="inner_block">

                <img src="photo/ForgotPassClose.png" class="close-block">

                <header class="pass-header1">Reset Password</header>

                <form name="passform" method="POST" id="pass-form" onsubmit="return false" novalidate>
                    <!-- First Box -->
                    <div class="pass-input-field0 first_box" id="reset-pass">
                        <input type="text" id="reset_pass" name="resetpass" class="pass-textbox0" maxlength="6" required/>
                        <label>UserID</label>
                    </div>

                    <div class="pass-btn1 first_box" onclick="send_otp1()" id="p-btn1">
                        <div class="pass-inner1"></div>
                        <button name="resetbtn" class="pass-login-btn1" value="SUBMIT" id="reset_btn">SUBMIT</button>
                    </div>

                    <!-- Second Box -->
                    <div class="pass-input-field0 second_box" id="reset-pass-otp">
                        <input type="text" id="reset_pass_otp" name="resetpassotp" class="pass-textbox0" maxlength="6" required/>
                        <label>OTP</label>
                    </div>

                    <div class="second_box">
                        <p id="timep" class="time_p">REQUEST FOR NEW OTP IN <span id="time">01:00</span> MINUTES!</p>
                    </div>

                    <div class="pass-btn1 second_box" onclick="submit_otp1()" id="p-btn2">
                        <div class="pass-inner1"></div>
                        <button name="otpbtn" class="pass-login-btn1" id="otp_btn">SUBMIT</button>
                    </div>

                    <!-- Third Box -->
                    <div class="pass-input-field0 third_box" id="new-pass">
                        <input type="password" id="new_pass" name="newpass" class="pass-textbox0" required/>
                        <label>Password</label>
                        <span id="passouter-eye">
                            <i id="pass_eye" show="no" class="pfas pslash-eye"></i>
                        </span>
                    </div>
                    
                    <div class="pass-input-field0 third_box" id="renew-pass">
                        <input type="password" id="renew_pass" name="renewpass" class="pass-textbox0" required/>
                        <label>Re-Password</label>
                        <span id="repassouter-eye">
                            <i id="repass_eye" show="no" class="pfas pslash-eye"></i>
                        </span>
                    </div>

                    <div class="pass-btn1 third_box" onclick="resetpassword()" id="p-btn3">
                        <div class="pass-inner1"></div>
                        <button name="newpassbtn" class="pass-login-btn1" value="SUBMIT" id="newpass_btn">SUBMIT</button>
                    </div>
                    
                </form>
            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////////////// -->

        <!-- ////////////////////////////////////////////////////////////////////////////////////// Right Wrong Popup-->
        <div id="wrongValidation" class="wmodal">

            <div class="wmodal-content">

                <div class="wcircle">
                    <span class="w11 w1"></span>
                    <span class="w22 w2"></span>
                </div>

                <p class="wtitle-text"></p>
                <p class="winfo-text"></p>

                <span class="wok-content-block" id="wspan">
                    <span class="wok-text">OK</span>
                </span></br></br>

            </div>

        </div>

        <div id="rightValidation" class="rmodal">
            <div class="rmodal-content">
                
                <div class="rcircle-loader">
                    <div class="rcheckmark rdraw"></div>
                </div>

                <p class="rtitle-text"></p>
                <p class="rinfo-text"></p>

                <span class="rok-content-block" id="rspan">
                    <span class="rok-text">OK</span>
                </span></br></br>

            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////////////// -->
    </body>
</html>
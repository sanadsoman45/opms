function login()
{
	var userid = jQuery("#user_id1").val();
	var password=jQuery("#pass_word1").val();
	if(userid != "" && password != ""){
		if(userid.match(/[0-9]/g)){
			jQuery.ajax({
				url:"TeacherLogin.php",
				type:"POST",
				dataType:"json",
				data:{"userid":userid,"password":password,"function":"teacher_login"},
				success:function(resp){
					if(resp["connerror"]=="yes"){
						wrongVal("Sorry!","Error in connecting to database");
					}else if(resp["invalidid"]=="invalidid"){
						wrongVal("Sorry!","Invalid Id");
					}else if(resp["passnotset"]=="true"){
						wrongVal("Sorry!","Password Not Set");
					}else if(resp["invalidpass"]=="true"){
						wrongVal("Sorry!","Invalid Password");
					}else{
						localStorage.setItem("tid", resp["tid"]);
						localStorage.setItem("tname", resp["tname"]);
						localStorage.setItem("tpin", resp["tpin"]);
						localStorage.setItem("temail", resp["temail"]);
						localStorage.setItem("tpn", resp["tpn"]);
		                location.href = "http://localhost/pro/MAINFILE8/Teacher%20Module/TeacherModule.php";
		            }
				}
			})
		}
	}
}

function logout(){
	localStorage.removeItem("tid");
	localStorage.removeItem("tname");
	localStorage.removeItem("tpin");
	localStorage.removeItem("temail");
	localStorage.removeItem("tpn");
	$.post("TeacherLogin.php",function(){
        location.href="TeacherLogin.php";
    });
}
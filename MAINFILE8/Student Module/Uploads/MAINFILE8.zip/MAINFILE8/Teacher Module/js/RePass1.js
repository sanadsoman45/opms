var ui_gr_digits0 = /^([0-9]+)$/g;
var pw_digits0 = /[0-9]/g;
var pw_uppercaseletters0 = /[A-Z]/g;
var pw_special0 = /[\@\$\&\#\!\%]/g;
var pw_lowcaseletters0 = /[a-z]/g;
var pw_nospecial0 = /^([a-zA-Z0-9\s\@\$\&\#\!\%]+)$/g;
var fn_letters2 = /^([a-zA-Z\s]+)$/g;
var email_addr2 = /^[a-zA-Z0-9]{1,20}\@[a-zA-Z]{2,5}\.[a-z]{2,4}$/g;

$(document).ready(function() {
    $("#forgot-password1").click(function() {
        $(".outer-block").css("display", "flex");
        $("#user_id1").val("");
        $("#pass_word1").val("");
        $("#outer-eye1").hide();
    });
});

$(document).ready(function() {
    $(".close-block").click(function() {
        $(".outer-block").css("display", "none");
        $("#reset_pass").val("");
        $("#reset_pass_otp").val("");
        $("#new_pass").val("");
        $("#renew_pass").val("");
        $("#repassouter-eye").hide();
        $("#passouter-eye").hide();
    });
});

var t;
var si;

function sessionReset() {
    var curpage = (window.location.href).substr((window.location.href).lastIndexOf("/") + 1);
    t = setTimeout(function redirectlogpage() {
        if(curpage == "StudLogSign.php"){
            window.location = "StudLogSign.php";
        }else if(curpage == "TeacLogSign.php"){
            window.location = "TeacLogSign.php";
        }
    }, 5 * 60000);
}

function startTimer(duration, display) {
    var timer = duration,
        minutes, seconds;
    si = setInterval(function() {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;
        display.textContent = minutes + ":" + seconds;
        if (--timer < 0) {
            clearInterval(si);
            $("#timep").hide();
            $(".inner-block").css("height", "290px");
            $("#otp_btn").html('RESEND OTP');
            $("#p-btn2").attr("onclick", "pvalidformchange()");
        }
    }, 1000);
}

function pvalidformchange() {
    $("#p-btn2").attr("onclick", "");
    send_otp1();
    $("#otp_btn").html('SUBMIT');
}

$(document).ready(function() {
    $("#passouter-eye").hide();
    $("#repassouter-eye").hide();

    $("#pass_eye").on('click', function() {
        if ($(this).attr("show") === "no") {
            $(this).attr("show", "yes");
            $(this).removeClass("pslash-eye");
            $(this).addClass("peye");
            $("#new_pass").attr("type", "text");
            $("#new_pass").attr("autocomplete", "off");
        } else {
            $(this).attr("show", "no");
            $(this).removeClass("peye");
            $(this).addClass("pslash-eye");
            $("#new_pass").attr("type", "password");
        }
    });

    $("#repass_eye").on('click', function() {
        if ($(this).attr("show") === "no") {
            $(this).attr("show", "yes");
            $(this).removeClass("pslash-eye");
            $(this).addClass("peye");
            $("#renew_pass").attr("type", "text");
            $("#renew_pass").attr("autocomplete", "off");
        } else {
            $(this).attr("show", "no");
            $(this).removeClass("peye");
            $(this).addClass("pslash-eye");
            $("#renew_pass").attr("type", "password");
        }
    });

    var newpw = document.getElementById("new_pass");
    var newrpw = document.getElementById("renew_pass");

    $("#new_pass").on('keyup keydown', function() {

        if (newpw.value == "" || newpw.value == null) {
            $("#pass_eye").attr("show", "no");
            $("#pass_eye").removeClass("peye");
            $("#pass_eye").addClass("pslash-eye");
            $("#new_pass").attr("type", "password");
            $("#passouter-eye").hide();
        } else {
            $("#passouter-eye").show();
        }
    });

    $("#renew_pass").on('keyup keydown', function() {

        if (newrpw.value == "" || newrpw.value == null) {
            $("#repass_eye").attr("show", "no");
            $("#repass_eye").removeClass("peye")
            $("#repass_eye").addClass("pslash-eye")
            $("#renew_pass").attr("type", "password")
            $("#repassouter-eye").hide();
        } else {
            $("#repassouter-eye").show();
        }
    });
});

function pvalidform1() {
    if (($("#reset_pass").val()) == "" || ($("#reset_pass").val()) == null) {
        wrongVal("Sorry!", "User-Id Must Be Filled Out");
    } else if (!(($("#reset_pass").val()).match(/^([0-9]+)$/g))) {
        wrongVal("Sorry!", "User-Id Should Contain Only Digits From 0-9");
    } else if (($("#reset_pass").val()).length > 6) {
        wrongVal("Sorry!", "User-Id Cannot Exceed Length Of 6 Digits");
    } else {
        $("#p-btn1").attr("onclick", "send_otp1()");
        $("#p-btn1").click();
    }
}

function pvalidform2() {
    if (($("#reset_pass_otp").val()) == "" || ($("#reset_pass_otp").val()) == null) {
        wrongVal("Sorry!", "OTP Must Be Filled Out");
    } else if (!(($("#reset_pass_otp").val()).match(/^([0-9]+)$/g))) {
        wrongVal("Sorry!", "OTP Should Contain Only Digits From 0-9");
    } else {
        $("#p-btn2").attr("onclick", "submit_otp1()");
        $("#p-btn2").click();
    }
}

function pvalidform3() {
    if (($("#new_pass").val()) == "" || ($("#new_pass").val()) == null) {
        wrongVal("Sorry!", "Password Must Be Filled Out");
    } else if (!(($("#new_pass").val()).match(/[a-z]/g))) {
        wrongVal("Sorry!", "Lowercase Should Be Included");
    } else if (!(($("#new_pass").val()).match(/[A-Z]/g))) {
        wrongVal("Sorry!", "Uppercase Should Be Included");
    } else if (!(($("#new_pass").val()).match(/[0-9]/g))) {
        wrongVal("Sorry!", "Digits Should Be Included");
    } else if (($("#new_pass").val()) != ($("#new_pass").val()).match(/^([a-zA-Z0-9\s\@\$\&\#\!\%]+)$/g)) {
        wrongVal("Sorry!", "SpecialCase Should Be Included Only (@ $ & # ! %)");
    } else if (!(($("#new_pass").val()).match(/[\@\$\&\#\!\%]/g))) {
        wrongVal("Sorry!", "SpecialCase Should Be Included");
    } else if (($("#new_pass").val()).length < 8) {
        wrongVal("Sorry!", "At Least 8 Or More Characters Should Be Included");
    } else if (($("#renew_pass").val()) == "" || ($("#renew_pass").val()) == null) {
        wrongVal("Sorry!", "RePassword Must Be Filled Out");
    } else if (($("#renew_pass").val()) != ($("#new_pass").val())) {
        wrongVal("Sorry!", "Password Not Match");
    } else {
        $("#p-btn3").attr("onclick", "resetpassword()");
        $("#p-btn3").click();
    }
}

function send_otp1() {
    var curpage = (window.location.href).substr((window.location.href).lastIndexOf("/") + 1);
    var userid = jQuery("#reset_pass").val();
    if (userid == null || userid == "") {
        wrongVal("Error", "ID FIELD IS EMPTY");
    } else if (!(userid.match(ui_gr_digits0))) {
        wrongVal("Sorry!", "User-Id Should Contain Only Digits From 0-9");
    }
    else
    {
        $("#p-btn1").attr("onclick", "");
        jQuery.ajax({
            url: "DataBase.php",
            type: "POST",
            dataType: "json",
            data: { "userid": userid, "function": "idverify", "curpage": curpage },
            success: function(result0) {
                if (result0["conn"] == "cno") {
                    console.log('Connection Can\'t Be Established...');
                    $("#p-btn1").attr("onclick", "pvalidform1()");
                }
                else if(result0["sessexp"]=="yes"){
                    wrongVal("Sorry","SIGN IN AGAIN");
                    $("#p-btn1").attr("onclick", "pvalidform1()");
                }
                else if(result0["verified"]=="no"){
                    wrongVal("Sorry","VERIFY YOUR EMAIL");
                    $("#p-btn1").attr("onclick", "pvalidform1()");
                }
                else if(result0["signresp"]=="no"){
                    wrongVal("ERROR","FIRST SIGN IN");
                    $("#p-btn1").attr("onclick", "pvalidform1()");
                } else if (result0['status'] == "yes") {
                    jQuery('.second_box').show();
                    jQuery('.close-block').hide();
                    jQuery('.first_box').hide();
                    jQuery('.third_box').hide();
                    rightVal('YUP!', 'Check Your Registered Email');
                    display = document.querySelector('#time');
                    startTimer(60 * 1, display);
                    $("#timep").show();
                    $(".inner-block").css("height", "310px");
                    sessionReset();
                    $("#p-btn1").attr("onclick", "pvalidform1()");
                    $("#p-btn2").attr("onclick", "pvalidform2()");
                } else if (result0['stat'] == "no") {
                    wrongVal('SORRY!', 'You Can Change Password After ' + "\t" + result0['datediff'] + '\t' + ' Day');
                    $("#p-btn1").attr("onclick", "pvalidform1()");
                } 
                else if(result0["invalidid"]=="yes"){
                    wrongVal("ERROR","INVALID ID");
                    $("#p-btn1").attr("onclick", "pvalidform1()");
                } else{
                    jQuery('.first_box').show();
                    jQuery('.second_box').hide();
                    jQuery('.third_box').hide();
                    wrongVal("Error","VERIFY YOUR EMAIL");
                    $("#p-btn1").attr("onclick", "pvalidform1()");
                }
                console.log(result0["resp"]);
                console.log(result0["id"]);
                console.log(result0["curpage"]);
                console.log("stud is:"+result0["resp1"]);
                console.log("teacher is:"+result0["resp1"]);
            }
        });
    }
    
}

function submit_otp1() {
    var curpage = (window.location.href).substr((window.location.href).lastIndexOf("/") + 1);
    var otp = jQuery("#reset_pass_otp").val();
    $("#p-btn2").attr("onclick", "");
    jQuery.ajax({
        url: "DataBase.php",
        type: "POST",
        dataType: "json",
        data: { "otp": otp, "function": "otpverify", "curpage": curpage },
        success: function(result1) {
            if (result1["conn"] == "cno") {
                console.log('Connection Can\'t Be Established...');
                $("#p-btn2").attr("onclick", "pvalidform2()");
            } else if (result1['status'] === "yes") {
                jQuery('.second_box').hide();
                jQuery('.first_box').hide();
                jQuery('.third_box').show();
                $(".inner-block").css("height", "390px");
                $(".inner-block").css("animation", "MoveUpDown 0.8s linear");
                clearInterval(si);
                $("#p-btn2").attr("onclick", "pvalidform2()");
            } else {
                jQuery('.second_box').show();
                jQuery('.first_box').hide();
                jQuery('.third_box').hide();
                wrongVal('SORRY!', 'INVALID OTP');
                $("#p-btn2").attr("onclick", "pvalidform2()");
            }
        }
    });
}

function resetpassword() {
    $("#p-btn3").attr("onclick", "");
    var curpage = (window.location.href).substr((window.location.href).lastIndexOf("/") + 1);
    var pass2 = jQuery("#renew_pass").val();
    jQuery.ajax({
        url: "DataBase.php",
        type: "POST",
        dataType: "json",
        data: { "renewpass": pass2, "function": "otpval", "curpage": curpage },
        success: function(result2) {
            if (result2["conn"] == "cno") {
                console.log('Connection Can\'t Be Established...');
                $("#p-btn3").attr("onclick", "pvalidform3()");
            } else if (result2['status'] === "yes") {
                clearTimeout(t);
                rightVal('SUCESS!', 'Password Changed Sucessfully');
                $("#new-pass").attr("id", "new-pass-flag");
                setTimeout(function() {
                    window.location = "StudLogSign.php";
                }, 1000 * 10);
                jQuery('.close-block').show();
                $("#p-btn3").attr("onclick", "pvalidform3()");
            } else {
                wrongVal('SORRY!', 'Old Password Can\'t be Used Again');
                $("#p-btn3").attr("onclick", "pvalidform3()");
            }
        }
    });
}

function login(abx) {
    console.log(abx);
    var curpage = abx;
    var id = jQuery("#user_id1").val();
    var pass = jQuery("#pass_word1").val();
    console.log(id + "" + pass);
    if ((id == "" && pass == "") || (id == null && pass == null)) {
        wrongVal("ERROR", "ID AND PASSWORD FIELD CANNOT BE EMPTY");
    } else if (id == "") {
        wrongVal("ERROR", "ID CANNOT BE EMPTY");
    } else if (pass == "") {
        wrongVal("ERROR", "PASWORD FIELD CANNOT BE EMPTY");
    } else {
        jQuery.ajax({
            url: "DataBase.php",
            type: "POST",
            dataType: "json",
            data: { "id": id, "pass": pass, "function": "login", "curpage": curpage },
            success: function(resp) {
                if (resp["conn"] == "no") {
                    console.log('Connection Can\'t Be Established...');
                }
                if (resp["curpage"] == "student") {
                    if (resp["pass"] == "no") {
                        wrongVal("ERROR", "WRONG PASSWORD");
                    }
                    if (resp["signin"] == "no") {
                        wrongVal("ERROR", "PLEASE SIGNIN");
                    }
                    if (resp["id"] == "no") {
                        wrongVal("Error", "INVALID ID");
                    }
                    if (resp["emailV"] == "no") {
                        wrongVal("Error", "Email NOT VERIFIED");
                    }
                    if(resp["sessexp"]=="yes")
                    {
                        wrongVal("Error","SIGNIN AGAIN");
                    }
                    if(resp["invalidid"]=="invalid"){
                        wrongVal("ERROR","USER NOT FOUND");
                    }
                    if(resp["signresp"]=="no")
                    {
                        wrongVal("ERROR","FIRST SIGN IN");
                    }
                    if(resp["login"]=="sucess")
                    {
                        sessionStorage.setItem("name",resp["stud"]);
                        localStorage.setItem("name1", resp["stud"]);
                        sessionStorage.setItem("id",id);
                        location.href="StudentModule.php";    
                    }
                    
                }
                if (resp["curpage"] == "teacher") {
                    if (resp["pass"] == "no") {
                        wrongVal("ERROR", "WRONG PASSWORD");
                    }
                    if (resp["signin"] == "false") {
                        wrongVal("ERROR", "PLEASE SIGNIN");
                    }
                    if (resp["id"] == "no") {
                        wrongVal("Error", "INVALID ID");
                    }
                    if (resp["emailV"] == "no") {
                        wrongVal("Error", "Email NOT VERIFIED");
                    }
                    if(resp["sessexp"]=="yes")
                    {
                        wrongVal("Error","SIGNIN AGAIN");
                    }
                    if(resp["invalidid"]=="invalid"){
                        wrongVal("ERROR","USER NOT FOUND");
                    }
                    if(resp["signresp"]=="no")
                    {
                        wrongVal("ERROR","FIRST SIGN IN");
                    }
                    if(resp["login"]=="sucess")
                    {
                        rightVal("SUCESS","WELCOME"+resp['teacher']);
                    }
                }
                if (resp["curpage"] == "admin") {
                    console.log("andaradmin");
                    console.log(resp["stud"]);
                    rightVal("Welcome", "Admin " + resp["stud"]);
                }
                
                console.log("email is:"+resp["email-time"]);
                console.log("time is"+resp["time"]);
                console.log("else resp is:"+resp["in"]);

            },
            error: function(error) {
                console.log(error);
                jQuery("#user_id1").val('');
                jQuery("#pass_word1").val('');
            }
        });
    }

}

function logout(abx)
{
    if(abx=="stud")
    {
        console.log("student logout k andar");
        jQuery.ajax({
            url: "DataBase.php",
            type: "POST",
            dataType:"json",
            data: { "curpage": abx,"function":"logout" },
            success: function(resp) {
                console.log("Response is:"+resp["logout"]);
                //rightVal("Sucess","LOGGED OUT SUCESSFULLY");
                if(resp["logout"]=="yes")
                {
                    
                    sessionStorage.removeItem("name");
                    sessionStorage.removeItem("id");
                    localStorage.removeItem("name1");
                    location.href="StudLogSign.php";
                }
                
            },
            error: function(error) {
                console.log(error);
            }

        });
    }
}

function signup(abx) {
    console.log(abx);
    //var curpage = (window.location.href).substr((window.location.href).lastIndexOf("/") + 1);
    var curpage = abx;
    if (abx == "stud") {
        var id = jQuery("#user_id2").val();
        var grno = jQuery("#gr_no2").val();
        var fullname = jQuery("#full_name2").val();
        var pass1 = jQuery("#pass_word2").val();
        var pass2 = jQuery("#re_password2").val();
        var email = jQuery("#email_id2").val();
        console.log(id, grno, fullname, pass1, pass2, email);
        if (id == null || id == "") {
            wrongVal("Error", "ID FIELD IS EMPTY");
        } else if (!(id.match(ui_gr_digits0))) {
            wrongVal("Sorry!", "User-Id Should Contain Only Digits From 0-9");
        } else if (id.length > 6) {
            wrongVal("Sorry!", "User-Id Cannot Exceed Length Of 6 Digits");
        } else if (grno == null || grno == "") {
            wrongVal("Error", "GRNO FIELD IS EMPTY");
        } else if (!(grno.match(ui_gr_digits0))) {
            wrongVal("Sorry!", "Gr-Number Should Contain Only Digits From 0-9");
        } else if (fullname == null || fullname == "") {
            wrongVal("Error", "FULLNAME FIELD IS EMPTY");
        } else if (!(fullname.match(fn_letters2))) {
            wrongVal("Sorry!", "Full Name Should Contain Only Letters For Ex. (A-Z a-z)");
        } else if (pass1 == null || pass1 == "") {
            wrongVal("Error", "PASSWORD FIELD IS EMPTY");
        } else if (!(pass1.match(pw_lowcaseletters0))) {
            wrongVal("Sorry!", "Lowercase Should Be Included");
        } else if (!(pass1.match(pw_uppercaseletters0))) {
            wrongVal("Sorry!", "Uppercase Should Be Included");
        } else if (!(pass1.match(pw_digits0))) {
            wrongVal("Sorry!", "Digits Should Be Included");
        } else if (!(pass1.match(pw_special0))) {
            wrongVal("Sorry!", "SpecialCase Should Be Included");
        } else if (pass1.length < 8) {
            wrongVal("Sorry!", "At Least 8 Or More Characters Should Be Included");
        } else if (pass2 == null || pass2 == "") {
            wrongVal("Error", "RE-Enter PASSWORD FIELD IS EMPTY");
        } else if (!(pass2.match(pw_lowcaseletters0))) {
            wrongVal("Sorry!", "Lowercase Should Be Included");
        } else if (!(pass2.match(pw_uppercaseletters0))) {
            wrongVal("Sorry!", "Uppercase Should Be Included");
        } else if (!(pass2.match(pw_digits0))) {
            wrongVal("Sorry!", "Digits Should Be Included");
        } else if (!(pass2.match(pw_special0))) {
            wrongVal("Sorry!", "SpecialCase Should Be Included");
        } else if (pass2.length < 8) {
            wrongVal("Sorry!", "At Least 8 Or More Characters Should Be Included");
        } else if (email == null || email == "") {
            wrongVal("Error", "EMAIL FIELD IS EMPTY");
        } else if (!(email.match(email_addr2))) {
            wrongVal("Sorry!", "Invalid Email-ID");
        } else {
            console.log("studentsignup ajax k andar");
            jQuery.ajax({
                url: "DataBase.php",
                type: "POST",
                dataType: "json",
                data: { "id": id, "grno": grno, "fullname": fullname, "pass1": pass1, "pass2": pass2, "email": email, "function": "signup", "curpage": curpage },
                success: function(resp) {
                    if (resp["conn"] == "no") {
                        console.log('Connection Can\'t Be Established...');
                    }
                    else if(resp["verify"]=="true")
                    {
                        wrongVal("SORRY","VERIFY YOUR EMAIL");
                    } 
                    else if(resp["emailver"]=="no")
                    {
                        wrongVal("Error","VERIFY YOUR EMAIL");
                    }
                    else if (resp["grno"] == "no") {
                        console.log("gr k andar");
                        wrongVal('SORRY!', 'Your GR Number Does Not Match Your ID');
                    } else if (resp["email"] == "no") {
                        wrongVal('SORRY!', 'Email Already  Exsist');
                    } else if (resp["account"] == "exsist") {
                        wrongVal('SORRY!', 'Your Account Is Already Created');
                    } else if (resp["userid"] == "exsist") {
                        wrongVal('SORRY', 'User ID Does Not Exsist');
                    } else if (resp["emailstat"] == "no") {
                        wrongVal('SORRY', 'Email Does Not Exsist');
                    } 
                    else if(resp["sessexp"]=="yes")
                    {
                        wrongVal("Error","SIGN IN AGAIN");
                    }else if (resp["account"] == "created") {
                        console.log("Account created");
                        rightVal('WEll Done!', 'CHECK YOUR EMAIL');
                        $("#eye12").removeClass("peye");
                        $("#eye12").addClass("pslash-eye");
                        $("#eye22").removeClass("peye");
                        $("#eye22").addClass("pslash-eye");
                        jQuery("#user_id2").val('');
                        jQuery("#gr_no2").val('');
                        jQuery("#full_name2").val('');
                        jQuery("#pass_word2").val('');
                        jQuery("#re_password2").val('');
                        jQuery("#email_id2").val('');
                        jQuery("#outer-eye12").hide();
                        jQuery("#outer-eye22").hide();
                    }else if(resp["email1"] == "no"){
                        wrongVal("SORRY","VERIFY YOUR EMAIL");
                    }
                    console.log(resp["email-time"]);
                },
                error: function(error) {
                    console.log(error);
                    jQuery("#user_id2").val('');
                    jQuery("#gr_no2").val('');
                    jQuery("#full_name2").val('');
                    jQuery("#pass_word2").val('');
                    jQuery("#re_password2").val('');
                    jQuery("#email_id2").val('');
                }
            });
        }
    } else if (abx == "teacher") {
        var id = jQuery("#user_id2").val();
        var fullname = jQuery("#full_name2").val();
        var pass1 = jQuery("#pass_word2").val();
        var pass2 = jQuery("#re_password2").val();
        var email = jQuery("#email_id2").val();
        var code = jQuery("#verify_code").val();
        console.log("code is:" + code);

        if (id == null || id == "") {
            wrongVal("Error", "ID FIELD IS EMPTY");
        } else if (!(id.match(ui_gr_digits0))) {
            wrongVal("Sorry!", "User-Id Should Contain Only Digits From 0-9");
        } else if (id.length > 6) {
            wrongVal("Sorry!", "User-Id Cannot Exceed Length Of 6 Digits");
        } else if (fullname == null || fullname == "") {
            wrongVal("Error", "FULLNAME FIELD IS EMPTY");
        } else if (!(fullname.match(fn_letters2))) {
            wrongVal("Sorry!", "Full Name Should Contain Only Letters For Ex. (A-Z a-z)");
        } else if (pass1 == null || pass1 == "") {
            wrongVal("Error", "PASSWORD FIELD IS EMPTY");
        } else if (!(pass1.match(pw_lowcaseletters0))) {
            wrongVal("Sorry!", "Lowercase Should Be Included");
        } else if (!(pass1.match(pw_uppercaseletters0))) {
            wrongVal("Sorry!", "Uppercase Should Be Included");
        } else if (!(pass1.match(pw_digits0))) {
            wrongVal("Sorry!", "Digits Should Be Included");
        } else if (!(pass1.match(pw_special0))) {
            wrongVal("Sorry!", "SpecialCase Should Be Included");
        } else if (pass1.length < 8) {
            wrongVal("Sorry!", "At Least 8 Or More Characters Should Be Included");
        } else if (pass2 == null || pass2 == "") {
            wrongVal("Error", "RE-Enter PASSWORD FIELD IS EMPTY");
        } else if (!(pass2.match(pw_lowcaseletters0))) {
            wrongVal("Sorry!", "Lowercase Should Be Included");
        } else if (!(pass2.match(pw_uppercaseletters0))) {
            wrongVal("Sorry!", "Uppercase Should Be Included");
        } else if (!(pass2.match(pw_digits0))) {
            wrongVal("Sorry!", "Digits Should Be Included");
        } else if (!(pass2.match(pw_special0))) {
            wrongVal("Sorry!", "SpecialCase Should Be Included");
        } else if (pass2.length < 8) {
            wrongVal("Sorry!", "At Least 8 Or More Characters Should Be Included");
        } else if (email == null || email == "") {
            wrongVal("Error", "EMAIL FIELD IS EMPTY");
        } else if (!(email.match(email_addr2))) {
            wrongVal("Sorry!", "Invalid Email-ID");
        } else if (code == "") {
            wrongVal("ERROR", "CODE CANNOT BE EMPTY");
        } else if (!code.match(ui_gr_digits0)) {
            wrongVal("ERROR", "ONLY NUMBERS ALLOWED");
        } else {
            jQuery.ajax({
                url: "DataBase.php",
                type: "POST",
                dataType: "json",
                data: { "id": id, "fullname": fullname, "pass1": pass1, "pass2": pass2, "email": email, "code": code, "function": "signup", "curpage": curpage },
                success: function(resp) {
                    if (resp["conn"] == "no") {
                        console.log('Connection Can\'t Be Established...');
                    }else if(resp["verify"]=="true")
                    {
                        wrongVal("SORRY","VERIFY YOUR EMAIL");
                    } else if (resp["userid"] == "no") {
                        wrongVal('SORRY', 'User ID Does Not Exsist');
                    } else if (resp["code"] == "no") {
                        wrongVal('SORRY', 'INVALID CODE');
                    } else if (resp["email"] == "no") {
                        wrongVal('SORRY!', 'Email Already  Exsist');
                    }
                    else if (resp["email1"] == "no") {
                        wrongVal('SORRY!', 'VERIFY YOUR EMAIL');
                    } 
                    else if (resp["account"] == "notvercre") {
                        wrongVal('SORRY!', 'EMAIL NOT VERIFIED');
                    }else if (resp["account"] == "exsist") {
                        wrongVal('SORRY!', 'Your Account Is Already Created');
                    } else if (resp["emailstat"] == "no") {
                        wrongVal('SORRY!', 'EMAIL NOT SENT');
                    } else if (resp["account"] == "no") {
                        wrongVal('SORRY!', 'INVALID ID');
                    } else if(resp["sessexp"]=="yes")
                    {
                        wrongVal("Error","SIGN IN AGAIN");
                    }else if (resp["account"] == "created") {
                        $("#passouter-eye").hide();
                        $("#repassouter-eye").hide();
                        rightVal("SUCESS", "CHECK YOUR EMAIL");
                        jQuery("#user_id2").val('');
                        jQuery("#gr_no2").val('');
                        jQuery("#full_name2").val('');
                        jQuery("#pass_word2").val('');
                        jQuery("#re_password2").val('');
                        jQuery("#email_id2").val('');
                        $("#passouter-eye").hide();
                        $("#repassouter-eye").hide();
                        jQuery("#verify_code").val('');

                    }
                    console.log(resp["id"]);
                },
                error: function(error) {
                    console.log(error);

                }
            });


        }
    }


}
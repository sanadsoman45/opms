<html>
	<head>
		<title>Teacher Module</title>

		<link href="css/Header.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="css/TeacherModule.css">
        <link rel="stylesheet" type="text/css" href="css/ApprRejBox.css">
        <link href="css/UserSetting.css" rel="stylesheet">
        <link href="css/Details.css" rel="stylesheet">
        <link href="css/SlidingMenu.css" rel="stylesheet">
        <link href="css/Footer.css" rel="stylesheet">

        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.js"></script>
		<script src="js/UserSetting.js"></script>
        <script src="js/teacher_ajax.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
            if(localStorage.getItem("tname") == null)
            {
                $.post("TeacherLogin.php",function(){
                    location.href="TeacherLogin.php";
                });
            }
            if(localStorage.getItem("DarkMode") == null){
                localStorage.setItem("DarkMode", "TOFF");
            }
            });
        </script>
	</head>
	<body>
		<!-- //////////////////////////////////////////////////////////////////////////////Header -->
        <header class="header">
            <div class="navigationBar" onclick="openNav()">
                <div class="nb1"></div>
                <div class="nb2"></div>
                <div class="nb3"></div>
            </div>

            <div class="proTitle">
                Project Management System
            </div>

            <div class="nbItems">
                <div class="nbItem" id="nbItem1">
                    <span class="nbIName nbIName1" style="font-size:25px;">Home</span>
                    <div class="nbIOutline" id="nbIOutline1" style="display: block;"></div>
                </div>
                <div class="nbItem" id="nbItem3" onclick="nbclick3()">
                    <span  class="nbIName nbIName3">About Us</span>
                    <div class="nbIOutline" id="nbIOutline3"></div>
                </div>
                <div class="nbItem" id="nbItem4" onclick="nbclick4()">
                    <span  class="nbIName nbIName4">FAQs</span>
                    <div class="nbIOutline" id="nbIOutline4"></div>
                </div>
            </div>

            <div class="userImage" id="user_Image">
                <img class="uImage" src="photo/male.png" alt="User Image">
            </div>
        </header>
        <br/>
        <!-- ////////////////////////////////////////////////////////////////////////////// -->

        <!-- ////////////////////////////////////////////////////////////////////////////// Teacher Module-->
        <div class="outer_TMSelectStages">
            <p class="TMSelectStagesText">Stage 1</p>
            <img class="TM_down_arrow" src="photo/t_down_arrow.png">
            <div class="TMSelectStagesLine"></div>
            <div class="outer_TMAllStages" myVal="Stage 1">
                <div class="TMAllStages TMAllStage1">Stage 1</div>
                <div class="TMAllStages TMAllStage2">Stage 2</div>
                <div class="TMAllStages TMAllStage3">Stage 3</div>
                <div class="TMAllStages TMAllStage4">Stage 4</div>
                <div class="TMAllStages TMAllStage5">Stage 5</div>
                <div class="TMAllStages TMAllStage6">Stage 6</div>
                <div class="TMAllStages TMAllStage7">Stage 7</div>
                <div class="TMAllStages TMAllStageFP">Final Project</div>
            </div>
        </div>
        <div class="outer_TMSearchBox">
            <div class="outer_TMSearchTextField">
                <input type="text" class="TMSearchTextField" placeholder="Search Students...">
            </div>
        </div>
        <div class="outer_pagination">
            <table class="TMtable">
                <thead>
                    <tr style="user-select: none">
                        <th>Student ID</th>
                        <th>Student Name</th>
                        <th>Project Name</th>
                        <th>Project Description</th>
                        <th>Project Type</th>
                        <th>Date Of Submission</th>
                        <th>Download</th>
                        <th>Response</th>
                    </tr>
                </thead>
                <tbody id="Tbody">
                    <tr>
                        <td class="abc">18</td>
                        <td>Akash</td>
                        <td style="width: 10em">Online Project Submission & Management System</td>
                        <td class="thDescription"><p class="thDescriptionText">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.</p> <img src="photo/t_down_arrow.png" class="TdownArrow"></td>
                        <td>Web Development</td>
                        <td>18/09/2020</td>
                        <td><div class="outer_TMDownloadBtn"><input type="button" value="Download" class="TMDownloadBtn"></div></td>
                        <td>
                            <img src="photo/Tcorrect.png" class="TMcorrect">
                            <img src="photo/Tquit.png" class="TMquit">
                        </td>
                    </tr>
                    <tr>
                        <td class="abc">22</td>
                        <td>Sanad</td>
                        <td style="width: 10em">Online Project Submission & Management System</td>
                        <td class="thDescription"><p class="thDescriptionText">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.</p> <img src="photo/t_down_arrow.png" class="TdownArrow"></td>
                        <td>Android Application</td>
                        <td>20/09/2020</td>
                        <td><div class="outer_TMDownloadBtn"><input type="button" value="Download" class="TMDownloadBtn"></div></td>
                        <td>
                            <img src="photo/Tcorrect.png" class="TMcorrect">
                            <img src="photo/Tquit.png" class="TMquit">
                        </td>
                    </tr>
                    <tr>
                        <td class="abc">23</td>
                        <td>Sanio</td>
                        <td style="width: 10em">Online Project Submission & Management System</td>
                        <td class="thDescription"><p class="thDescriptionText">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.</p> <img src="photo/t_down_arrow.png" class="TdownArrow"></td>
                        <td>Android Application</td>
                        <td>20/09/2020</td>
                        <td><div class="outer_TMDownloadBtn"><input type="button" value="Download" class="TMDownloadBtn"></div></td>
                        <td>
                            <img src="photo/Tcorrect.png" class="TMcorrect">
                            <img src="photo/Tquit.png" class="TMquit">
                        </td>
                    </tr>
                    <tr>
                        <td class="abc">20</td>
                        <td>Shubham</td>
                        <td style="width: 10em">Online Project Submission & Management System</td>
                        <td class="thDescription"><p class="thDescriptionText">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.</p> <img src="photo/t_down_arrow.png" class="TdownArrow"></td>
                        <td>Android Application</td>
                        <td>20/09/2020</td>
                        <td><div class="outer_TMDownloadBtn"><input type="button" value="Download" class="TMDownloadBtn"></div></td>
                        <td>
                            <img src="photo/Tcorrect.png" class="TMcorrect">
                            <img src="photo/Tquit.png" class="TMquit">
                        </td>
                    </tr>
                    <tr>
                        <td class="abc">25</td>
                        <td>Sagar</td>
                        <td style="width: 10em">Online Project Submission & Management System</td>
                        <td class="thDescription"><p class="thDescriptionText">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.</p> <img src="photo/t_down_arrow.png" class="TdownArrow"></td>
                        <td>Android Application</td>
                        <td>20/09/2020</td>
                        <td><div class="outer_TMDownloadBtn"><input type="button" value="Download" class="TMDownloadBtn"></div></td>
                        <td>
                            <img src="photo/Tcorrect.png" class="TMcorrect">
                            <img src="photo/Tquit.png" class="TMquit">
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="outer_TMnextPage">
            <img src="photo/TnextArrow.png" class="TMnextPage1">
            <p class="TMPage TMOnePage">1</p>
            <p class="TMPage TMTwoPage">2</p>
            <p class="TMPage TMThreePage">3</p>
            <img src="photo/TnextArrow.png" class="TMbackPage2">
        </div>
        <br/>
        <!-- ////////////////////////////////////////////////////////////////////////////// -->

        <!-- ////////////////////////////////////////////////////////////////////////////// Approved/Rejected Box -->
        <div class="outer_ApprRejBox">
            <div class="ApprRejBox">
                <p class="ARHeader"></p>
                <p class="ARQue">Are you sure to proceed?</p>
                <p class="ARResponse">If you are <label class="ARResAccep"></label>, Please write your response.</p>
                <div class="outer_ARTextarea">
                    <textarea class="ARTextarea" placeholder="Reason..."></textarea>
                </div>
                <div class="outer_ARCancelBtn">
                    <input type="button" class="ARCancelBtn" value="Cancel">
                </div>
                <div class="outer_ARProceedBtn">
                    <input type="button" class="ARProceedBtn" value="Proceed">
                </div>
            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////// -->

		<!-- ////////////////////////////////////////////////////////////////////////////// User Setting-->
        <div class="set-outer-block" id="set_outer_block">
            <div class="userSetting">
                
                <div class="userImage1">
                    <img class="uImage1" src="photo/male.png" alt="User Image">
                    <!-- <div class="userOnline"></div> -->
                </div>

                <div class="userName" id="username">
                    Username
                </div>

                <div class="outer-details">
                    <div class="details">
                        <div class="d1 d11"></div>
                        <div class="d2"></div>
                        <div class="d1"></div>
                        <div class="d2"></div>
                        <div class="d1"></div>
                        <div class="d2"></div>
                    </div>
                    <div class="DetailsName">
                        Details
                    </div>
                </div>

                <div class="outer-UpdateAccName" onclick="accountSetting()">
                    <div>
                        <img class="settingIcon" src="photo/settings-icon.png" alt="settings icon">
                    </div>
                    <div class="UpdateAcc">
                        Manage & Update Your Account
                    </div>
                </div>

                <div class="logout">
                    <input type="button" name="logout" class="logoutBut" value="LOGOUT" id="log_out1" onclick='logout()'/>
                </div>
            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////// -->

        <!-- ////////////////////////////////////////////////////////////////////////////// Details-->
        <div class="outer-DetailsBox" id="outer_DetailsBox">
            <div class="main-DetailsBox">
                <header class="detailsHeader">Details</header>
                <img src="photo/DialogBoxClose.png" class="closeDetails">
                <div class="userNameDetail">
                    <div class="setUserName" id="setUserName">Akash Katkar</div>
                </div>

                <div class="userIdDetail">
                    <div class="setuserId" id="setuserId">101</div>
                </div>

                <div class="grNumDetail">
                    <div class="setGrNum" id="setGrNum">5005</div>
                </div>

                <div class="emailIdDetail">
                    <div class="setEmailId" id="setEmailId">skykatkar6666@gmail.com</div>
                </div>

                <div class="numberDetail">
                    <div class="setNumber" id="setNumber">9429731685</div>
                </div>
            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////// -->

        <!-- ////////////////////////////////////////////////////////////////////////////// Sliding Menu-->

        <div class="outer-slidingMenu" id="outer_slidingMenu">
            <div class="slidingMenu">
                <div>
                    <div class="logo-outer-circle">
                        <img class="logo" src="photo/logoY.png" alt="User Image">
                    </div>

                    <div class="pmsName">
                        Project Management System
                    </div>
                </div>

                <div class="menuItem chats">
                    <div class="uPName">
                        Chats
                    </div>
                    <div class="arrow">
                        <div class="arrow1"></div>
                        <div class="arrow2"></div>
                    </div>
                </div>

                <div class="menuItem visitCollegeSite">
                    <div class="uPName">
                        Visit College Site
                    </div>
                    <div class="arrow">
                        <div class="arrow1"></div>
                        <div class="arrow2"></div>
                    </div>
                </div>

                <div class="menuItem darkMode">
                    <div class="uPName">
                        Dark Mode
                    </div>
                    <label class="darkSlider">
                        <input type="checkbox" class="darkCheckbox"/>
                        <div class="darkToNormal"></div>
                    </label>
                </div>

                <div class="bluePartIncrease"></div>
            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////// -->

        <!-- ////////////////////////////////////////////////////////////////////////////// Footer-->
        <footer class="footer">
            <div class="outer-circle-name">
                <div class="logo-outer-circle0">
                    <img class="logo0" src="photo/logoY.png" alt="User Image">
                </div>

                <div class="pmsName0">
                    Database and Record Project Management System
                </div>
            </div>

            <div class="outer-main">
                <div class="main">Main</div>
                <div class="home0" id="home_0">Home</div><br/>
                <div class="aboutUs0" id="aboutUs_0" onclick="nbclick3()">About Us</div><br/>
                <div class="faqs0" id="faqs_0" onclick="nbclick4()">FAQs</div>
            </div>
    
            <div class="outer-resources">
                <div class="resources">Resources</div>
                <div class="contactUs">Contact Us</div><br/>
                <div class="blog">Blog</div>
            </div>

            <div class="outer-legal">
                <div class="legal">Legal</div>
                <div class="termsOfUse">Terms Of Use</div><br/>
                <div class="privacyPolicy">Privacy Policy</div>
            </div>

            <div class="outer-social">
                <div class="social">Social</div>
                <div class="facebook">Facebook</div><br/>
                <div class="instagram">Instagram</div><br/>
                <div class="twitter">Twitter</div><br/>
                <div class="linkedIn">LinkedIn</div>
            </div>

            <div class="dotted-line"></div>
            
            <div class="dataBase">@DataBase.in.2000</div>
        </footer>
        <!-- ////////////////////////////////////////////////////////////////////////////// -->

        <script type="text/javascript">
            document.getElementById("username").innerHTML=localStorage.getItem("tname");
            document.getElementById("setuserId").innerHTML=localStorage.getItem("tid");
            document.getElementById("setUserName").innerHTML=localStorage.getItem("tname");
            document.getElementById("setGrNum").innerHTML=localStorage.getItem("tpin");
            document.getElementById("setEmailId").innerHTML=localStorage.getItem("temail");
            document.getElementById("setNumber").innerHTML=localStorage.getItem("tpn");
        </script>
	</body>
</html>
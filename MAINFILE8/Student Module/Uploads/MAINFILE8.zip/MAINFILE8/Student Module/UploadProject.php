<html>
    <head>
        <title>Upload Project</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link href="css/UploadProject.css" rel="stylesheet">
        <link href="css/RSwal.css" rel="stylesheet" />
        <link href="css/WSwal.css" rel="stylesheet" />

        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.js"></script>
        <script src="js/UserSetting.js"></script>
        <script src="js/RightWrongPopup1.js"></script>
        <!-- <script>
            $(document).ready(function(){
                if(localStorage.getItem("name1") == null)
                {
                    $.post("StudentLogin.php",function(){
                        location.href="StudentLogin.php";
                    });
                }
            }); 
        </script> -->
    </head>
    <body>

        <!-- ////////////////////////////////////////////////////////////////////////////// Upload Project-->
        <br>
        <div>
            <!-- <header class="stage"></header> -->
            <div class="MainUploadProject">
            <header class="stage"></header>
                <div class="uPHeader"></div>

                <div class="Format">
                    <select class="text_type_Format" required>
                        <option selected style="display:none;"></option>
                        <option value="pdf">PDF File</option>
                        <option value="doc">DOC File</option>
                        <option value="docx">DOCX File</option>
                    </select>
                    <label>Format (Upload as *)</label>
                    <div class="FArrow">
                        <img src="photo/down-arrow1.png" class="FArrow1">
                        <img src="photo/down-arrow2.png" class="FArrow2">
                    </div>
                </div>

                <div class="uploadPro">
                    <div class="clickForUpload">
                        <input type="file" class="fileUploadPro" accept=".pdf, .docx, .doc" title="" disabled>
                        <div class="foldPage"></div>
                        <div class="chooseFiles">CHOOSE FILES</div>
                        <div class="uploadLine"></div>
                        <img src="photo/down-arrow1.png" class="uploadArrow">
                    </div>
                    <div class="dropFile">Drop Your File Here</div>
                    <p class="dFileName"></p>
                </div>

                <div class="cancel">
                    <input type="button" class="btnCancel" onclick="cancel()" value="CANCEL">
                </div>

                <div class="uploadButton">
                    <input type="button" class="uploadBtn" value="UPLOAD">
                </div>
            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////// -->

        <!-- ///////////////////////////////////////////////////////////////////////////////////// RIGHT WRONG POPUP-->
        <div id="wrongValidation" class="wmodal">

            <div class="wmodal-content">

                <div class="wcircle">
                    <span class="w11 w1"></span>
			        <span class="w22 w2"></span>
                </div>

                <p class="wtitle-text"></p>
                <p class="winfo-text"></p>

                <span class="wok-content-block" id="wspan">
                    <span class="wok-text">OK</span>
                </span></br></br>

            </div>

        </div>

        <div id="rightValidation" class="rmodal">
            <div class="rmodal-content">
                
                <div class="rcircle-loader">
                    <div class="rcheckmark rdraw"></div>
                </div>

                <p class="rtitle-text"></p>
                <p class="rinfo-text"></p>

                <span class="rok-content-block" id="rspan">
                    <span class="rok-text">OK</span>
                </span></br></br>

            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////////////// -->
    </body>
</html>
<html>
    <head>
        <title>View Project</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link href="css/ViewProject.css" rel="stylesheet">
        <link href="css/Details.css" rel="stylesheet">

        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.js"></script>
        <script src="js/UserSetting.js"></script>
        <!-- <script>
            $(document).ready(function(){
                if(localStorage.getItem("name1") == null)
                {
                    $.post("StudentLogin.php",function(){
                        location.href="StudentLogin.php";
                    });
                }
            }); 
        </script> -->
    </head>
    <body>
        <!-- //////////////////////////////////////////////////////////////////////////// View Project -->
        <div class="smallCircle">
            <div class="allCircles">
                <div class="cStage1">
                    <div class="smallRight sR1">
                        <img class="smallRightIcon" src="photo\correct.png">
                    </div>
                    <div class="smallWrong sW1">
                        <div class="rw1"></div>
                        <div class="rw2"></div>
                    </div>
                    <div class="smallWating sWt1">
                        <img class="smallWaitingIcon" src="photo\confirmationIcon.png">
                    </div>
                    <div class="smallOpenLock sOL1">
                        <p class="number">1</p>
                    </div>
                </div>

                <div class="lStage2"></div>
                <div class="cStage2">
                    <div class="smallRight sR2">
                        <img class="smallRightIcon" src="photo\correct.png">
                    </div>
                    <div class="smallWrong sW2">
                        <div class="rw1"></div>
                        <div class="rw2"></div>
                    </div>
                    <div class="smallWating sWt2">
                        <img class="smallWaitingIcon" src="photo\confirmationIcon.png">
                    </div>
                    <div class="smallOpenLock sOL2">
                        <p class="number">2</p>
                    </div>
                </div>

                <div class="lStage3"></div>
                <div class="cStage3">
                    <div class="smallRight sR3">
                        <img class="smallRightIcon" src="photo\correct.png">
                    </div>
                    <div class="smallWrong sW3">
                        <div class="rw1"></div>
                        <div class="rw2"></div>
                    </div>
                    <div class="smallWating sWt3">
                        <img class="smallWaitingIcon" src="photo\confirmationIcon.png">
                    </div>
                    <div class="smallOpenLock sOL3">
                        <p class="number">3</p>
                    </div>
                </div>

                <div class="lStage4"></div>
                <div class="cStage4">
                    <div class="smallRight sR4">
                        <img class="smallRightIcon" src="photo\correct.png">
                    </div>
                    <div class="smallWrong sW4">
                        <div class="rw1"></div>
                        <div class="rw2"></div>
                    </div>
                    <div class="smallWating sWt4">
                        <img class="smallWaitingIcon" src="photo\confirmationIcon.png">
                    </div>
                    <div class="smallOpenLock sOL4">
                        <p class="number">4</p>
                    </div>
                </div>

                <div class="lStage5"></div>
                <div class="cStage5">
                    <div class="smallRight sR5">
                        <img class="smallRightIcon" src="photo\correct.png">
                    </div>
                    <div class="smallWrong sW5">
                        <div class="rw1"></div>
                        <div class="rw2"></div>
                    </div>
                    <div class="smallWating sWt5">
                        <img class="smallWaitingIcon" src="photo\confirmationIcon.png">
                    </div>
                    <div class="smallOpenLock sOL5">
                        <p class="number">5</p>
                    </div>
                </div>

                <div class="lStage6"></div>
                <div class="cStage6">
                    <div class="smallRight sR6">
                        <img class="smallRightIcon" src="photo\correct.png">
                    </div>
                    <div class="smallWrong sW6">
                        <div class="rw1"></div>
                        <div class="rw2"></div>
                    </div>
                    <div class="smallWating sWt6">
                        <img class="smallWaitingIcon" src="photo\confirmationIcon.png">
                    </div>
                    <div class="smallOpenLock sOL6">
                        <p class="number">6</p>
                    </div>
                </div>
                
                <div class="lStage7"></div>
                <div class="cStage7">
                    <div class="smallRight sR7">
                        <img class="smallRightIcon" src="photo\correct.png">
                    </div>
                    <div class="smallWrong sW7">
                        <div class="rw1"></div>
                        <div class="rw2"></div>
                    </div>
                    <div class="smallWating sWt7">
                        <img class="smallWaitingIcon" src="photo\confirmationIcon.png">
                    </div>
                    <div class="smallOpenLock sOL7">
                        <p class="number">7</p>
                    </div>
                </div>
            </div>
        </div>

        <div>
            <br/><br/><br/>
            <div class="intro">
                <p class="introName">Title & Intro</p>
                <img class="introCircleImg" onclick="uploadproject('01')" src="photo/Stage_1_normal.png" />
                <p class="succeCreated intrS">SUCCESSFULLY CREATED</p>
                <p class="rejected intrR">REJECTED</p>
                <div class="viewHere introViewHere">View Here</div>
                <p class="watingConfo intrW">WAITING FOR CONFORMATION</p>
            </div>
            <div class="requir">
                <p class="requirName">Requirement</p>
                <img class="requirementCircleImg" src="photo/Stage_2_block.png" />
                <p class="succeCreated requS">SUCCESSFULLY CREATED</p>
                <p class="rejected requR">REJECTED</p>
                <div class="viewHere requirViewHere">View Here</div>
                <p class="watingConfo requW">WAITING FOR CONFORMATION</p>
            </div>
            <div class="design">
                <p class="designName">Design</p>
                <img class="designCircleImg" src="photo/Stage_3_block.png" />
                <p class="succeCreated desiS">SUCCESSFULLY CREATED</p>
                <p class="rejected desiR">REJECTED</p>
                <div class="viewHere designViewHere">View Here</div>
                <p class="watingConfo desiW">WAITING FOR CONFORMATION</p>
            </div>
            <div class="impleme">
                <p class="implemeName">Implementation</p>
                <img class="implementationCircleImg" src="photo/Stage_4_block.png" />
                <p class="succeCreated implS">SUCCESSFULLY CREATED</p>
                <p class="rejected implR">REJECTED</p>
                <div class="viewHere implemeViewHere">View Here</div>
                <p class="watingConfo implW">WAITING FOR CONFORMATION</p>
            </div>
            <div class="result">
                <p class="resultName">Results</p>
                <img class="resultCircleImg" src="photo/Stage_5_block.png" />
                <p class="succeCreated resuS">SUCCESSFULLY CREATED</p>
                <p class="rejected resuR">REJECTED</p>
                <div class="viewHere resultViewHere">View Here</div>
                <p class="watingConfo resuW">WAITING FOR CONFORMATION</p>
            </div>
            <div class="conclu">
                <p class="concluName">Conclusion & Future Scope</p>
                <img class="conclusionCircleImg" src="photo/Stage_6_block.png" />
                <p class="succeCreated concS">SUCCESSFULLY CREATED</p>
                <p class="rejected concR">REJECTED</p>
                <div class="viewHere concluViewHere">View Here</div>
                <p class="watingConfo concW">WAITING FOR CONFORMATION</p>
            </div>
            <div class="refere">
                <p class="refereName">References</p>
                <img class="referenceCircleImg" src="photo/Stage_7_block.png" />
                <p class="succeCreated refeS">SUCCESSFULLY CREATED</p>
                <p class="rejected refeR">REJECTED</p>
                <div class="viewHere refereViewHere">View Here</div>
                <p class="watingConfo refeW">WAITING FOR CONFORMATION</p>
            </div>
        </div>

        <div class="outer_viewProjDownloadImg">
            <img src="photo/viewProjDownload.png" class="viewProjDownloadImg">
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////// -->

        <!-- ////////////////////////////////////////////////////////////////////////////// Download Files-->
        <div class="outer_viewProDownload">
            <div class="viewProDownload">
                <div class="vPDLBluePart7"></div>
                <img src="photo/AccountSettingBack.png" class="vPDLBack">
                <p class="vPDLHeader">Download Your Uploaded Files</p>
                <div class="vPDLBox vPDLBox1">
                    <p class="vPDLBoxText">1. Title & Introduction</p>
                    <img src="photo/VPDLBoxBack.png" class="vPDLBoxImg vPDLBoxImg1">
                </div>
                <div class="vPDLBox vPDLBox2">
                    <p class="vPDLBoxText">2. Requirement</p>
                    <img src="photo/VPDLBoxBack.png" class="vPDLBoxImg vPDLBoxImg2">
                </div>
                <div class="vPDLBox vPDLBox3">
                    <p class="vPDLBoxText">3. Design</p>
                    <img src="photo/VPDLBoxBack.png" class=" vPDLBoxImg vPDLBoxImg3">
                </div>
                <div class="vPDLBox vPDLBox4">
                    <p class="vPDLBoxText">4. Implementation</p>
                    <img src="photo/VPDLBoxBack.png" class="vPDLBoxImg vPDLBoxImg4">
                </div>
                <div class="vPDLBox vPDLBox5">
                    <p class="vPDLBoxText">5. Results</p>
                    <img src="photo/VPDLBoxBack.png" class="vPDLBoxImg vPDLBoxImg5">
                </div>
                <div class="vPDLBox vPDLBox6">
                    <p class="vPDLBoxText">6. Conclusion & Future Scope</p>
                    <img src="photo/VPDLBoxBack.png" class="vPDLBoxImg vPDLBoxImg6">
                </div>
                <div class="vPDLBox vPDLBox7">
                    <p class="vPDLBoxText">7. References</p>
                    <img src="photo/VPDLBoxBack.png" class="vPDLBoxImg vPDLBoxImg7">
                </div>
            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////// -->

        <!-- ////////////////////////////////////////////////////////////////////////////// Rejected Message-->
        <div class="outer-fPRejMess">
            <div class="fPRejMess">
                <p class="TeacReport">Teacher's Reports</p>
                <p class="rejMessMessage"></p>
                <p class="messHere">Message here.......</p>
                <div class="cancelRejMess">CANCEL</div>
                <div class="reURejMess">Re-Upload</div>
            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////// -->

        <!-- ////////////////////////////////////////////////////////////////////////////// Details-->
        <div class="outer-DetailsBox" id="outer_DetailsBox">
            <div class="main-DetailsBox">
                <header class="detailsHeader">Details</header>
                <img src="photo/DialogBoxClose.png" class="closeDetails">
                <div class="userNameDetail">
                    <div class="setUserName">Akash Katkar</div>
                </div>

                <div class="userIdDetail">
                    <div class="setuserId">101</div>
                </div>

                <div class="grNumDetail">
                    <div class="setGrNum">5005</div>
                </div>

                <div class="emailIdDetail">
                    <div class="setEmailId">skykatkar6666@gmail.com</div>
                </div>

                <div class="numberDetail">
                    <div class="setNumber">9429731685</div>
                </div>
            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////// -->
    </body>
</html>
<html>
	<head>
		<title>Add Admin</title>

		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<link rel="stylesheet" type="text/css" href="css/AddAdmin.css">
		<link href="css/RSwal.css" rel="stylesheet" />
        <link href="css/WSwal.css" rel="stylesheet" />

		<script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.js"></script>
        <script src="js/RightWrongPopup1.js"></script>
		<script>
			$(document).ready(function(){
				$(".AddAdminBtn").click(function(){
					var aid = $(".UserIDTextbox").val();
					var aname = $(".UserNameTextBox").val();
					var aemail = $(".EmailIDTextBox").val();
					var apn = $(".PinNumberTextbox").val();
					if(aid == "" || aid == null){
						wrongVal("Sorry!", "User ID Must Be Filled Out");
					}else if(!(aid.match(/^([0-9]+)$/g))){
						wrongVal("Sorry!", "User ID Should Contain Only Digits From 0-9");
					}else if(aname == "" || aname == null){
						wrongVal("Sorry!", "User Name Must Be Filled Out");
					}else if(!(aname.match(/^([a-zA-Z]+)$/g))){
						wrongVal("Sorry!", "Full Name Should Contain Only Letters For Ex. (A-Z a-z)");
					}else if(aemail == "" || aemail == null){
						wrongVal("Sorry!", "Email ID Must Be Filled Out");
					}else if(!(aemail.match(/^[a-zA-Z0-9]{1,20}\@[a-zA-Z]{2,5}\.[a-z]{2,4}$/g))){
						wrongVal("Sorry!", "Invalid Email-ID");
					}else if(apn == "" || apn == null){
						wrongVal("Sorry!", "Contact Number Must Be Filled Out");
					}else if(!(apn.match(/^([0-9]+)$/g))){
						wrongVal("Sorry!", "Contact Number Should Contain Only Digits From 0-9");
					}else if(apn.length != 10){
						wrongVal("Sorry!", "Contact Number Should Contain Only 10 Digits Number");
					}else{
						jQuery.ajax({
				            url: "db.php",
				            type: "POST",
				            dataType: "json",
							data:{"fun": "accreg", "aid":aid, "aname":aname, "aemail":aemail, "apn":apn},
							success: function(results){
								console.log(results["conform"]);
							}
						});
					}
				});
			});
		</script>
	</head>
	<body>
		<div class="abc"></div>
		
		<form id="main-container" method="POST">
			<header>Please fill out the form to add admin</header>
			<div class="mainBox">
				<div class="main_UserIDTextbox">
					<p class="UserIDName">User ID</p>
					<div class="outer_UserIDTextbox">
		                <input type="text" class="UserIDTextbox" name="UserID_Textbox"/>
		            </div>
	            </div>

	            <div class="main_UserNameTextBox">
					<p class="UserName">User Name</p>
					<div class="outer_UserNameTextBox">
		                <input type="text" class="UserNameTextBox" name="UserName_TextBox"/>
		            </div>
	            </div>

	            <div class="main_EmailIDTextBox">
					<p class="EmailIDName">Email ID</p>
					<div class="outer_EmailIDTextBox">
		                <input type="text" class="EmailIDTextBox" name="EmailID_TextBox"/>
		            </div>
	            </div>

	            <div class="main_PinNumberTextbox">
					<p class="PinNumberName">Contact Number</p>
					<div class="outer_PinNumberTextbox">
		                <input type="text" class="PinNumberTextbox" name="PinNumber_Textbox" />
		            </div>
	            </div>

	            <div class="outer_AddAdminBtn">
		            <input type="button" value="Add Admin" class="AddAdminBtn">
		        </div>
			</div>
		</form>

		<!-- ///////////////////////////////////////////////////////////////////////////////////// RIGHT WRONG POPUP-->
        <div id="wrongValidation" class="wmodal">

            <div class="wmodal-content">

                <div class="wcircle">
                    <span class="w11 w1"></span>
			        <span class="w22 w2"></span>
                </div>

                <p class="wtitle-text"></p>
                <p class="winfo-text"></p>

                <span class="wok-content-block" id="wspan">
                    <span class="wok-text">OK</span>
                </span></br></br>

            </div>

        </div>

        <div id="rightValidation" class="rmodal">
            <div class="rmodal-content">
                
                <div class="rcircle-loader">
                    <div class="rcheckmark rdraw"></div>
                </div>

                <p class="rtitle-text"></p>
                <p class="rinfo-text"></p>

                <span class="rok-content-block" id="rspan">
                    <span class="rok-text">OK</span>
                </span></br></br>

            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////////////// -->
	</body>
</html>
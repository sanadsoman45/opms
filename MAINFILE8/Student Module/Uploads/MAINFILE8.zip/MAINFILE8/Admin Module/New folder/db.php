<?php
	if($_POST["fun"] == "accreg"){
		$aid = $_POST["aid"];
		$aname = $_POST["aname"];
		$aemail = $_POST["aemail"];
		$apn = $_POST["apn"];

		$conn = mysqli_connect("localhost","akash","Hello8","demo");
		$query= "insert into admin_details values($aid ,'$aname', '', '$aemail', '$apn');";
	    mysqli_query($conn, $query);

	    $vkey=md5($aid);
	    $to ="skykatkar6666@gmail.com";
	    $subject = "SEND ID";
	    $txt = "<a href='http://localhost/pro/MAINFILE7/Admin%20Module/setPassword.php?vkey=$vkey'>Set Password</a>";
	    $headers = "From:cartoonlovers185@gmail.com";
	    if(mail($to,$subject,$txt,$headers)){
			$return_data["conform"] = "YES";
	    }else{
			$return_data["conform"] = "NO";
	    }
		echo json_encode($return_data);

		mysqli_close($conn);
	}else if($_POST["fun"] == "getid"){
		$url_components = parse_url($_POST["url"]); 
		parse_str($url_components['query'], $params);
		if($params['vkey']){
			$conn = mysqli_connect("localhost","akash","Hello8","demo");
			$query= "select * from admin_details;";
		    $result = mysqli_query($conn, $query);
		    if(mysqli_num_rows($result) > 0){
		    	while($row = mysqli_fetch_array($result)){
		    		if($params['vkey'] == md5($row["aid"])){
						$return_data["adminid"] = $row["aid"];
						$return_data["conform"] = "YUP";
						break;
		    		}else{
		    			$return_data["conform"] = "NOPE";
		    		}
		    	}
		    }
		}else{
		    $return_data["conform"] = "Nooooo";
		}
		echo json_encode($return_data);

		mysqli_close($conn);
	}else if($_POST["fun"] == "setpw"){
		$adminpw = $_POST["apw"];
		$adminid = $_POST["aid"];
		$conn = mysqli_connect("localhost","akash","Hello8","demo");
		$query= "UPDATE admin_details SET apw='$adminpw' WHERE aid=$adminid;";
		if(mysqli_query($conn, $query)){
			$return_data["setpass"] = "YUP";
		}else{
			$return_data["setpass"] = "NOPE";
		}
		echo json_encode($return_data);

		mysqli_close($conn);
	}
?>
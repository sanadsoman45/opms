<html>
	<head>
		<title>Add Admin</title>

		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<link rel="stylesheet" type="text/css" href="css/AddAdmin.css">
		<link href="css/RSwal.css" rel="stylesheet" />
        <link href="css/WSwal.css" rel="stylesheet" />

		<script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.js"></script>
        <script src="js/RightWrongPopup1.js"></script>
        <script>
        	$(document).ready(function() {
			    $("#outer-eye1").hide();
			    $("#outer-eye12").hide();

			    $("#eye1").on('click', function() {
			        if ($(this).attr("show") === "no") {
			            $(this).attr("show", "yes");
			            $(this).removeClass("pslash-eye");
			            $(this).addClass("peye");
			            $(".PasswordTextBox").attr("type", "text");
			            $(".PasswordTextBox").attr("autocomplete", "off");
			        } else {
			            $(this).attr("show", "no");
			            $(this).removeClass("peye");
			            $(this).addClass("pslash-eye");
			            $(".PasswordTextBox").attr("type", "password");
			        }
			    });
			    $("#eye12").on('click', function() {
			        if ($(this).attr("show") === "no") {
			            $(this).attr("show", "yes");
			            $(this).removeClass("pslash-eye");
			            $(this).addClass("peye");
			            $(".UserNameTextBox").attr("type", "text");
			            $(".UserNameTextBox").attr("autocomplete", "off");
			        } else {
			            $(this).attr("show", "no");
			            $(this).removeClass("peye");
			            $(this).addClass("pslash-eye");
			            $(".UserNameTextBox").attr("type", "password");
			        }
			    });

			    $(".PasswordTextBox").on('keyup keydown', function() {    
			        if($(".PasswordTextBox").val() == "" || $(".PasswordTextBox").val() == null)
			        {
			            $("#eye1").attr("show", "no");
			            $("#eye1").removeClass("peye");
			            $("#eye1").addClass("pslash-eye");
			            $(".PasswordTextBox").attr("type", "password");
			            $("#outer-eye1").hide();
			        }else{
			            $("#outer-eye1").show();
			        }
			    });
			    $(".UserNameTextBox").on('keyup keydown', function() { 
		            if($(".UserNameTextBox").val() == "" || $(".UserNameTextBox").val() == null)
		            {
		                $("#eye12").attr("show", "no");
		                $("#eye12").removeClass("peye");
		                $("#eye12").addClass("pslash-eye");
		                $(".UserNameTextBox").attr("type", "password");
		                $("#outer-eye12").hide();
		            }else{
		                $("#outer-eye12").show();
		            }
		        });
			});
        </script>
		<script>
			var url = window.location.href;
			jQuery.ajax({
	            url: "db.php",
	            type: "POST",
	            dataType: "json",
				data:{"fun": "getid", "url":url},
				success: function(results){
					console.log(results["conform"]);
					if(results["conform"] == "YUP"){
						$(".UserIDTextbox").val(results["adminid"]);
					}
				}
			});

			$(document).ready(function(){
				if($(".UserIDTextbox").val() == "" || $(".UserIDTextbox").val() == null){
					wrongVal("Sorry!", "Something Went Wrong");
				}
				$(".AddAdminBtns").click(function(){
					var apassword = $(".PasswordTextBox").val();
					var arepassword = $(".UserNameTextBox").val();
					var auserid = $(".UserIDTextbox").val();
					if (apassword == null || apassword == "") {
		            	wrongVal("Error", "PASSWORD FIELD IS EMPTY");
			        } else if (!(apassword.match(/[a-z]/g))) {
			            wrongVal("Sorry!", "Lowercase Should Be Included");
			        } else if (!(apassword.match(/[A-Z]/g))) {
			            wrongVal("Sorry!", "Uppercase Should Be Included");
			        } else if (!(apassword.match(/[0-9]/g))) {
			            wrongVal("Sorry!", "Digits Should Be Included");
			        } else if (!(apassword.match(/[\@\$\&\#\!\%]/g))) {
			            wrongVal("Sorry!", "SpecialCase Should Be Included");
			        } else if (apassword.length < 8) {
			            wrongVal("Sorry!", "At Least 8 Or More Characters Should Be Included");
			        } else if (arepassword == "" || arepassword == null) {
        				wrongVal("Sorry!", "RePassword Must Be Filled Out");
				    } else if (apassword != arepassword) {
				        wrongVal("Sorry!", "Password Not Match");
				    } else if(auserid != ""){
				    	console.log(auserid);
				    	jQuery.ajax({
				            url: "db.php",
				            type: "POST",
				            dataType: "json",
							data:{"fun": "setpw", "apw":arepassword, "aid":auserid},
							success: function(results){
								console.log(results["setpass"]);
								if(results["setpass"] == "YUP"){
									$.post("AdminLogin.php",function(){
							            location.href="AdminLogin.php";
							        });
								}
							}
						});
				    } else{
				        wrongVal("Sorry!", "Something Went Wrong");
				    }
			    });
			});
		</script>
	</head>
	<body>
		<div class="abc"></div>
		
		<form id="main-container" method="POST">
			<header>Please fill out the form to add admin</header>
			<div class="mainBox">
				<div class="main_UserIDTextbox">
					<p class="UserIDName">User ID</p>
					<div class="outer_UserIDTextbox">
		                <input type="text" class="UserIDTextbox" name="UserID_TB" disabled/>
		            </div>
	            </div>

	            <div class="main_PasswordTextBox">
					<p class="PasswordName">Password</p>
					<div class="outer_PasswordTextBox">
		                <input type="password" class="PasswordTextBox" name="Password_TB" />
		            </div>
	                <span id="outer-eye1">
                        <i id="eye1" show="no" class="fas pslash-eye"></i>
                    </span>
	            </div>

	            <div class="main_UserNameTextBox">
					<p class="UserName">Re-Password</p>
					<div class="outer_UserNameTextBox">
		                <input type="password" class="UserNameTextBox" name="RePassword_TB"/>
		            </div>
	                <span id="outer-eye12">
                        <i id="eye12" show="no" class="fas pslash-eye"></i>
                    </span>
	            </div>

	            <div class="outer_AddAdminBtn">
		            <input type="button" value="Add Admin" class="AddAdminBtns">
		        </div>
			</div>
		</form>

		<!-- ///////////////////////////////////////////////////////////////////////////////////// RIGHT WRONG POPUP-->
        <div id="wrongValidation" class="wmodal">

            <div class="wmodal-content">

                <div class="wcircle">
                    <span class="w11 w1"></span>
			        <span class="w22 w2"></span>
                </div>

                <p class="wtitle-text"></p>
                <p class="winfo-text"></p>

                <span class="wok-content-block" id="wspan">
                    <span class="wok-text">OK</span>
                </span></br></br>

            </div>

        </div>

        <div id="rightValidation" class="rmodal">
            <div class="rmodal-content">
                
                <div class="rcircle-loader">
                    <div class="rcheckmark rdraw"></div>
                </div>

                <p class="rtitle-text"></p>
                <p class="rinfo-text"></p>

                <span class="rok-content-block" id="rspan">
                    <span class="rok-text">OK</span>
                </span></br></br>

            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////////////////////////////// -->
	</body>
</html>